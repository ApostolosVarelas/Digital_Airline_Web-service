import pymongo
import json
from pymongo import MongoClient
from flask import Flask, request, jsonify, session


app = Flask(__name__)
app.secret_key = 'secret_key'
client = MongoClient('mongodb://mongodb:27017/')
db = client['DigitalAirlines']
users = db['users']
reservations = db['reservations']
flights = db['flights']

user_count = 0
#User Register
@app.route('/register', methods=['POST'])
def register():
    try:
        global user_count
        user_count = user_count + 1
        string = "UR"
        
        #Get user's data and store the to insert them to the collectoin
        user_data = request.json
        user_id = string+ str(user_count)
        user_data['_id'] = user_id
        firstname = user_data['firstname']
        lastname = user_data['lastname']
        email = user_data['email']
        password = user_data['password']
        date_of_birth = user_data['date_of_birth']
        country_of_origin = user_data['country_of_origin']
        passport_number = user_data['passport_number']
        
        user_data['type'] = 'User'
        user_data['_id'] = str(user_id)
        
        #Check if user already registered
        if users.find_one({'$and':[{'firstname': firstname},{'email': email}]}):
            return jsonify({'message': 'User already registered'}), 409  # 409 Conflict

        # Insert new user to the database
        users.insert_one(user_data)
        
        return jsonify({'message': 'User registered successfully'}), 201  # 201 Created
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400 # 400 Bad Request

#Login
@app.route('/login', methods=['POST'])
def login():
    try:
        #Get user's data
        user_data = request.json
        email = user_data['email']
        password = user_data['password']
        user = users.find_one({'$and':[{'email': email},{'password': password}]})
        
        #Check if the credentials are correct
        if not user:
            return jsonify({'message': 'Wronge email or password. Please enter your email and password.'}), 401  # 401 Unauthorized
        
        #Use session so programm can have access of the id and the type of the user to multiple functions
        session['type'] = user['type']
        session['_id'] = user['_id']
        return jsonify({'message': 'User login successfully'}), 200  # 200 OK
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request
    
#Logout
@app.route('/logout', methods=['POST'])
def logout():
    
    #Check if someone is logged in
    if 'type' in session and '_id' in session:
        session.pop('type')
        session.pop('_id')
        return jsonify({'message': 'User logout successfully.'}), 200  # 200 OK
    
    return jsonify({'message': 'No user already logged in.'}), 401  # 401 Unauthorized
#USER 

#Search for all flights
@app.route('/flight_search', methods=['GET'])
def flight_search():
    try:
        #Check if someone is logged in
        if '_id' in session:
            #Get user's data
            user_data = request.json
            choice = user_data['choice']
            flight_data = []
            
        #If statement for the user's choice
            if choice == 0:
                origin = user_data['origin']
                destination = user_data['destination']
                flight = flights.find({'$and': [{'origin': origin}, {'destination': destination}]})
                
                flight_data = []
                for document in flight:
                    data = {'_id': document.get('_id'), 'date': document.get('date'), 'origin': document.get('origin'), 'destination': document.get('destination')}
                    flight_data.append(data)
                
                if flight_data:
                    return jsonify({'message': 'Flights found:', 'data': flight_data}), 200  # 200 OK
                else:
                    return jsonify({'message': 'Could not find a flight with those filters'}), 404  # 404 Not Found
            elif choice == 1:
                origin = user_data['origin']
                destination = user_data['destination']
                date = user_data['date']
                flight = flights.find({'$and': [{'origin': origin}, {'destination': destination}, {'date': date}]})
                
                flight_data = []
                #Check if the flight id is correct 
                for document in flight:
                    data = { '_id': document.get('_id'), 'date': document.get('date'), 'origin': document.get('origin'), 'destination': document.get('destination')}
                    flight_data.append(data)
                    
                if flight_data:
                    return jsonify({'message': 'Flights found:', 'data': flight_data}), 200  # 200 OK
                else:
                    return jsonify({'message': 'Could not find a flight with those filters'}), 404  # 404 Not Found
            
            elif choice == 2:
                date = user_data['date']
                flight = flights.find({'date': date})
                
                flight_data = []
                #Check if the flight id is correct 
                for document in flight:
                    data = { '_id': document.get('_id'), 'date': document.get('date'), 'origin': document.get('origin'), 'destination': document.get('destination')}
                    flight_data.append(data)

                if flight_data:
                    return jsonify({'message': 'Flights found:', 'data': flight_data}), 200  # 200 OK
                else:
                    return jsonify({'message': 'Could not find a flight with those filters'}), 404  # 404 Not Found
            
            elif choice == 3:
                flight = flights.find()
                
                flight_data = []
                #Check if the flight id is correct  
                for document in flight:
                    data = { '_id': document.get('_id'), 'date': document.get('date'), 'origin': document.get('origin'), 'destination': document.get('destination')}
                    flight_data.append(data)
                
                if flight_data:
                    return jsonify({'message': 'Flights found:', 'data': flight_data}), 200  # 200 OK
                else:
                    return jsonify({'message': 'Could not find a flight with those filters'}), 404  # 404 Not Found 
            
            else:
                return jsonify({'message': 'Please enter a valid choice'}), 400  # 400 Bad Request
        
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request\
            
#Search for one flight
@app.route('/one_flight_search', methods = ['GET'])
def one_flight_search():
    try:
        
        #Check if someone is logged in
        if '_id' in session:
            user_data = request.json
            flight_id = user_data['_id']
            flight = flights.find_one({'_id': flight_id})
            
            #Check if the flight id is correct
            if flight:    
                flights_data = { 'date': flight.get('date'), 
                                'origin': flight.get('origin'), 
                                'destination': flight.get('destination'), 
                                'business_amount': flight.get('business_amount'), 
                                'economy_amount': flight.get('economy_amount'),
                                'business_cost': flight.get('business_cost'), 
                                'economy_cost': flight.get('economy_cost')}
                return jsonify({'message': 'Flights found:', 'data': flights_data}), 200  # 200 OK
                
            return jsonify({'message': 'Could not find the flight'}), 404  # 404 Not Found
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request   
    
reservation_count = 0

#Make a reservation
@app.route('/reservation', methods = ['POST'])
def reservation():
    try:
        global reservation_count

        #Check if someone is logged in
        if '_id' in session:
                
            reservation_count = reservation_count + 1
            string  = 'RS'
            
            #Get user's data and store the to insert them to the collectoin
            user_data = request.json
            user_data['_id'] = string+ str(reservation_count)
            user = session['_id']
            flight_id = user_data['flight_id']
            user_data['user'] = user
            firstname = user_data['firstname']
            lastname = user_data['lastname']
            passport_number = user_data['passport_number']
            date_of_birth = user_data['date_of_birth']
            email = user_data['email']
            ticket_type = user_data['ticket_type']
                
            #Check if the ticker type is correct
            if ticket_type != "Business" and ticket_type != "Economy":
                return jsonify({'message': 'Invalid type of ticker. Please choice Business or Economy.'}), 400
                
            flight = flights.find_one({'_id': flight_id})
            
            #Check if the flight_id is correct
            if flight:
                business_amount = flight['business_amount']
                economy_amount = flight['economy_amount']
            #If statement for the type of the ticket
                if ticket_type == 'Business':
                    if business_amount > 0:
                        # Insert new reservation into the database
                        reservations.insert_one(user_data)
                        flights.update_one({'_id': flight_id}, {'$inc': {'business_amount': -1}})
                        return jsonify({'message': 'Reservation registered successfully'}), 201  # 201 Created
                    return jsonify({'message': 'Business seats are full for this flight.'}), 409  # 400 Conflict 
                else:
                    if economy_amount > 0:
                        # Insert new reservation into the database
                        reservations.insert_one(user_data)
                        flights.update_one({'_id': flight_id}, {'$inc': {'economy_amount': -1}})
                        return jsonify({'message': 'Reservation registered successfully'}), 201  # 201 Created
                    return jsonify({'message': 'Economy seats are full for this flight.'}), 400  # 400 Conflict 
            return jsonify({'message': 'Could not find the flight you are looking for.'}), 404  # 404 Not Found
            
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request
    
#Show the reservation
@app.route('/show_reservation', methods = ['GET'])
def show_reservation():
    
    #Check if someone is logged in
    if '_id' in session:
        user_id = session['_id']
        reservation = reservations.find({'user': user_id})
        
        #Check id reservation_id is correct
        if reservation:
            reservation_data = []
            for document in reservation:
                data = {'_id': document.get('_id'), 'flight_id': document.get('flight_id'), 'ticket_type': document.get('ticket_type')}
                reservation_data.append(data)
            return jsonify({'message': 'Reservations found:', 'data': reservation_data}), 200  # 200 OK
        return jsonify({'message': 'You have not made any reservations.'}), 404  # 404 Not Found
    return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    
#Show reservation details
@app.route('/reservation_details', methods = ['GET'])
def reservation_details():
    try:
        #Check if someone is logged in
        if '_id' in session:
            user_data = request.json
            reservation_id = user_data['_id']
            reservation = reservations.find_one({'_id': reservation_id})
            
            #Check if reservation_id is correct 
            if reservation:
                
                #Get flight_id from reservation
                flight_id = reservation['flight_id']
                flight = flights.find_one({'_id': flight_id})    
            
                #Check if user wants to view his reservation
                if session['_id'] == reservation['user']:
                    data = { 'origin': flight.get('origin'),
                            'destination': flight.get('destination'),
                            'date': flight.get('date'),
                            'firstname': reservation.get('firstname'), 
                            'lastname': reservation.get('lastname'), 
                            'passport_number': reservation.get('passport_number'),
                            'date_of_birth': reservation.get('date_of_birth'), 
                            'email': reservation.get('email'), 
                            'ticket_type': reservation.get('ticket_type')}
                    return jsonify({'message': 'Reservation found', 'data': data}), 200  # 200 OK
                return jsonify({'message': 'You can only view your reservations'}), 401  # 401 Unauthorized
            return jsonify({'message': 'Could not find the reservation.'}), 404  # 404 Not Found
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request
 
#Cancel the reservation
@app.route('/cancel_reservation', methods = ['POST'])
def cancel_reservation():
    try:
        #Check if someone is logged in
        if '_id' in session:
            user_data = request.json
            reservation_id = user_data['_id']
            reservation = reservations.find_one({'_id': reservation_id})
            
            #Check if reservations_id is correct
            if reservation:
                
                #Get flight_id from reservation
                flight_id = reservation['flight_id']
                ticket = reservation['ticket_type']

                #Check if user wants to cancel his reservation
                if session['_id'] == reservation['user']:
                    reservations.delete_one({'_id': reservation_id})
                    
                    if ticket == 'Business':
                        flights.update_one({'_id': flight_id}, {'$inc': {'business_amount': 1}})
                    else:
                        flights.update_one({'_id': flight_id}, {'$inc': {'economy_amount': 1}})
                    return jsonify({'message': 'Reservation deleted successfully.'}), 200  # 200 OK
                return jsonify({'message': 'You can only cancel your reservations.'}), 401  # 401 Unauthorized
            return jsonify({'message': 'Could not find the reservation.'}), 404  # 404 Not Found
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request

#Delete the users account
@app.route('/delete_acc', methods=['DELETE'])
def delete_acc():
    
    #Check if someone is logged in
    if '_id' in session:
            users.delete_one({'_id': session['_id']})
            session.pop('type')
            session.pop('_id')
            return jsonify({'message': 'User deleted successfully.'}), 200  # 200 OK

    return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized


#############################################################
#############################################################
#############################################################

#ADMIN
flight_count = 0
#Insert flight to the system
@app.route('/insert_flight', methods = ['POST'])
def insert_flight():
        
    try:
        global flight_count
        
        if 'type' in session: 
            if session['type'] == 'Admin': 
                flight_count = flight_count + 1
                string = "FL"
                
                # Get data for the flights
                user_data = request.json
                flight_id = string+ str(flight_count)
                user_data['_id'] = flight_id
                origin = user_data['origin']
                destination = user_data['destination']
                date = user_data['date']
                business_total_amount = user_data['business_total_amount']
                business_cost = user_data['business_cost']
                economy_total_amount = user_data['economy_total_amount']
                economy_cost = user_data['economy_cost']
                
                # Calculate the total amounts
                business_amount = business_total_amount
                economy_amount = economy_total_amount

                # Update the user_data dictionary with the total amounts
                user_data['business_amount'] = int(business_amount)
                user_data['economy_amount'] = int(economy_amount)
                
                # Insert new user to the database
                flights.insert_one(user_data)

                return jsonify({'message': 'Flight registered successfully! Flight ID: '+str(flight_id)}), 201  # 201 Created
            
            return jsonify({'message': 'Invalid action! Only admin can access this request.'}), 401  # 401 Unauthorized
        
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request
    
#Update the cost of a flight
@app.route('/flight_cost', methods = ['PUT'])
def flight_cost():
    try:
        if 'type' in session: 
            if session['type'] == 'Admin':
                user_data = request.json
                flight_id = user_data['_id']
                business_cost = user_data['business_cost']
                economy_cost = user_data['economy_cost']
                
                if flights.find_one({'_id': flight_id}):
                    flights.update_one({'_id': flight_id}, {'$set':{'business_cost': business_cost}})
                    flights.update_one({'_id': flight_id}, {'$set':{'economy_cost': economy_cost}})
                    
                    return jsonify({'message': 'Costs updated successfully.'}), 200  # 200 OK
                
                return jsonify({'message': 'This flight does not exist.'}), 404  # 404 Not Found
            
            return jsonify({'message': 'Invalid action! Only admin can access this request.'}), 401  # 401 Unauthorized
        
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request
    
#Remove a flight
@app.route('/delete_flight', methods = ['DELETE'])
def delete_flight():
    
    try:
        if 'type' in session: 
            if session['type'] == 'Admin':
                user_data = request.json
                flight_id = user_data['_id']
                flight = flights.find_one({'_id': flight_id})
                
                if flight:
                    flight_id = flight['_id']
                    reservation = reservations.find_one({'flight_id': flight_id})
                    
                    if reservation:
                        return jsonify({'message': 'You can νοτ delete a flight that has reservations.'}), 401  # 401 Unauthorized
                    
                    flights.delete_one({'_id': flight_id})
                    return jsonify({'message': 'Flight deleted successfully.'}), 200  # 200 OK

                return jsonify({'message': 'Could not find the flight'}), 404  # 404 Not Found
            
            return jsonify({'message': 'Invalid action! Only admin can access this request.'}), 401  # 401 Unauthorized
        
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request
    
#Search for a flight
@app.route('/admin_flight_search', methods = ['GET'])
def admin_flight_search():
    
    try:
        if 'type' in session: 
            if session['type'] == 'Admin':
                user_data = request.json
                flight_id = user_data['_id']
                flight = flights.find_one({'_id': flight_id})
                if flight:    
                    flights_data = {  
                                    'origin': flight.get('origin'), 
                                    'destination': flight.get('destination'),
                                    'total_tickets': int(int(flight.get('business_total_amount')) + int(flight.get('economy_total_amount'))),
                                    'business_total_amount': int(flight.get('business_total_amount')), 
                                    'economy_total_amount': int(flight.get('economy_total_amount')), 
                                    'total_available_tickets': flight.get('business_amount') + flight.get('economy_amount'),
                                    'business_amount': flight.get('business_amount'), 
                                    'economy_amount': flight.get('economy_amount'),
                                    'business_cost': int(flight.get('business_cost')), 
                                    'economy_cost': int(flight.get('economy_cost'))
                    }
                    
                    reservation = reservations.find({'flight_id': flight_id})
                    reservation_data = []

                    for document in reservation:
                        data = {
                            'firstname': document.get('firstname'),
                            'lastname': document.get('lastname'),
                            'ticket_type': document.get('ticket_type')
                        }
                        reservation_data.append(data)

                    if reservation_data:
                        return jsonify({'message': 'Flights found:', 'Flight data': flights_data, 'Reservation data': reservation_data}), 200  # 200 OK
                    else:
                        return jsonify({'message': f'Flight {flight_id} has no reservations', 'Flight data': flights_data}), 200  # 200 OK
                    
                return jsonify({'message': 'Could not find the flight'}), 404  # 404 Not Found
            
            return jsonify({'message': 'Invalid action! Only admin can access this request.'}), 401  # 401 Unauthorized
        
        return jsonify({'message': 'Invalid action! You must login first.'}), 401  # 401 Unauthorized
    except:
        return jsonify({'message': 'Please, make sure that you fild the field correct.'}), 400  # 400 Bad Request
    
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=6000)